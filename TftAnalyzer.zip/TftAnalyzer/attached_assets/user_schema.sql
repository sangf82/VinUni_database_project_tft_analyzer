CREATE TABLE IF NOT EXISTS users (
            name       VARCHAR(50) PRIMARY KEY,
            riotid     VARCHAR(21) NOT NULL,
            pw_hash    VARBINARY(60) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE Player(
    puuid varchar(100) PRIMARY KEY,
    gameName varchar(100),
    tagLine varchar(100),
    lastLP int,
    gamePlayed int
);

CREATE TABLE Champion (
    ChampionID VARCHAR(100) PRIMARY KEY
    
);

CREATE TABLE Match (
    MatchID varchar(100) PRIMARY KEY,
    gameLength DECIMAL(10, 2),
    endDatetime DATETIME
    
);

CREATE TABLE MatchPlayerInfo (
    puuid VARCHAR(100) REFERENCES Player(puuid) on delete CASCADE,
    MatchID VARCHAR(100) REFERENCES `Match`(MatchID),
    placement INT,
    currentLP INT,
    PRIMARY KEY (puuid, MatchID)
    
);

CREATE TABLE MatchPlayerChampionInfo (
    puuid VARCHAR(100) REFERENCES Player(puuid),
    MatchID VARCHAR(100) REFERENCES `Match`(MatchID),
    ChampionID VARCHAR(100) REFERENCES Champion(ChampionID),
    quantity INT,
    
    PRIMARY KEY (puuid, MatchID, ChampionID)
    
);