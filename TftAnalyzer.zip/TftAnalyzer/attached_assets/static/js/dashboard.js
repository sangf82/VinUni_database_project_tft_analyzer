// TFT Analyzer Dashboard JavaScript

// Global variables
let lpChart = null;
let refreshInterval = null;

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    setupEventListeners();
    startAutoRefresh();
});

/**
 * Initialize the dashboard components
 */
function initializeDashboard() {
    console.log('Initializing TFT Analyzer Dashboard...');
    
    // Add loading states
    showLoadingStates();
    
    // Initialize tooltips
    initializeTooltips();
    
    // Animate stat cards
    animateStatCards();
    
    // Hide loading states after a delay
    setTimeout(hideLoadingStates, 1000);
}

/**
 * Setup event listeners for interactive elements
 */
function setupEventListeners() {
    // Refresh button
    const refreshBtn = document.querySelector('[href*="refresh-data"]');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function(e) {
            e.preventDefault();
            refreshPlayerData();
        });
    }
    
    // Champion cards hover effects
    setupChampionHoverEffects();
    
    // Match row click handlers
    setupMatchRowHandlers();
    
    // Keyboard shortcuts
    setupKeyboardShortcuts();
}

/**
 * Setup auto-refresh functionality
 */
function startAutoRefresh() {
    // Refresh data every 5 minutes
    refreshInterval = setInterval(function() {
        refreshPlayerData(true); // Silent refresh
    }, 5 * 60 * 1000);
}

/**
 * Refresh player data from the server
 */
function refreshPlayerData(silent = false) {
    if (!silent) {
        showRefreshSpinner();
    }
    
    // Make request to refresh endpoint
    fetch('/refresh-data', {
        method: 'GET',
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        if (response.ok) {
            if (!silent) {
                showNotification('Data refreshed successfully!', 'success');
                // Reload the page to show updated data
                setTimeout(() => window.location.reload(), 1000);
            }
        } else {
            throw new Error('Failed to refresh data');
        }
    })
    .catch(error => {
        console.error('Error refreshing data:', error);
        if (!silent) {
            showNotification('Failed to refresh data. Please try again.', 'error');
        }
    })
    .finally(() => {
        if (!silent) {
            hideRefreshSpinner();
        }
    });
}

/**
 * Show loading states on dashboard elements
 */
function showLoadingStates() {
    const cards = document.querySelectorAll('.card-body');
    cards.forEach(card => {
        card.classList.add('shimmer');
    });
}

/**
 * Hide loading states
 */
function hideLoadingStates() {
    const cards = document.querySelectorAll('.card-body');
    cards.forEach(card => {
        card.classList.remove('shimmer');
        card.classList.add('fade-in-up');
    });
}

/**
 * Initialize Bootstrap tooltips
 */
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * Animate stat cards on load
 */
function animateStatCards() {
    const statCards = document.querySelectorAll('.col-lg-3');
    statCards.forEach((card, index) => {
        setTimeout(() => {
            card.classList.add('fade-in-up');
        }, index * 100);
    });
}

/**
 * Setup hover effects for champion cards
 */
function setupChampionHoverEffects() {
    const championItems = document.querySelectorAll('.list-group-item');
    championItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(5px)';
            this.style.transition = 'transform 0.3s ease';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
        });
    });
}

/**
 * Setup match row click handlers
 */
function setupMatchRowHandlers() {
    const matchRows = document.querySelectorAll('.table tbody tr');
    matchRows.forEach(row => {
        row.style.cursor = 'pointer';
        row.addEventListener('click', function() {
            // Add a subtle animation to indicate click
            this.style.transform = 'scale(1.02)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
            
            // Here you could navigate to a detailed match view
            // For now, just show a tooltip
            showNotification('Match details coming soon!', 'info');
        });
        
        row.addEventListener('mouseenter', function() {
            this.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.backgroundColor = '';
        });
    });
}

/**
 * Setup keyboard shortcuts
 */
function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl + R or F5 - Refresh data
        if ((e.ctrlKey && e.key === 'r') || e.key === 'F5') {
            e.preventDefault();
            refreshPlayerData();
        }
        
        // Escape - Clear notifications
        if (e.key === 'Escape') {
            clearNotifications();
        }
    });
}

/**
 * Show refresh spinner
 */
function showRefreshSpinner() {
    const refreshBtn = document.querySelector('[href*="refresh-data"]');
    if (refreshBtn) {
        const icon = refreshBtn.querySelector('i');
        const originalClass = icon.className;
        icon.className = 'fas fa-spinner fa-spin me-1';
        refreshBtn.disabled = true;
        
        // Store original state
        refreshBtn.dataset.originalIcon = originalClass;
    }
}

/**
 * Hide refresh spinner
 */
function hideRefreshSpinner() {
    const refreshBtn = document.querySelector('[href*="refresh-data"]');
    if (refreshBtn && refreshBtn.dataset.originalIcon) {
        const icon = refreshBtn.querySelector('i');
        icon.className = refreshBtn.dataset.originalIcon;
        refreshBtn.disabled = false;
        delete refreshBtn.dataset.originalIcon;
    }
}

/**
 * Show notification to user
 */
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = `
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    
    const iconMap = {
        'success': 'fas fa-check-circle',
        'error': 'fas fa-exclamation-triangle',
        'warning': 'fas fa-exclamation-circle',
        'info': 'fas fa-info-circle'
    };
    
    notification.innerHTML = `
        <i class="${iconMap[type] || iconMap.info} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

/**
 * Clear all notifications
 */
function clearNotifications() {
    const notifications = document.querySelectorAll('.alert.position-fixed');
    notifications.forEach(notification => {
        notification.remove();
    });
}

/**
 * Format numbers with commas
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/**
 * Format LP change with proper styling
 */
function formatLPChange(change) {
    const sign = change > 0 ? '+' : '';
    const className = change > 0 ? 'text-success' : 'text-danger';
    return `<span class="${className}">${sign}${change} LP</span>`;
}

/**
 * Get rank color based on tier
 */
function getRankColor(tier) {
    const colors = {
        'IRON': '#6b4423',
        'BRONZE': '#cd7f32',
        'SILVER': '#c0c0c0',
        'GOLD': '#ffd700',
        'PLATINUM': '#40e0d0',
        'DIAMOND': '#b9f2ff',
        'MASTER': '#9d4edd',
        'GRANDMASTER': '#ff6b6b',
        'CHALLENGER': '#f72585'
    };
    return colors[tier] || '#6c757d';
}

/**
 * Animate counter numbers
 */
function animateCounter(element, start, end, duration = 1000) {
    const range = end - start;
    const increment = range / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
            current = end;
            clearInterval(timer);
        }
        element.textContent = Math.floor(current);
    }, 16);
}

/**
 * Cleanup function for when page is unloaded
 */
window.addEventListener('beforeunload', function() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
    
    // Cleanup any ongoing animations or timers
    clearNotifications();
});

/**
 * Handle network errors gracefully
 */
window.addEventListener('online', function() {
    showNotification('Connection restored!', 'success');
    refreshPlayerData(true);
});

window.addEventListener('offline', function() {
    showNotification('You are offline. Some features may not work.', 'warning');
});

// Export functions for use in other scripts
window.TFTDashboard = {
    refreshPlayerData,
    showNotification,
    formatNumber,
    formatLPChange,
    getRankColor,
    animateCounter
};

console.log('TFT Analyzer Dashboard initialized successfully!');
