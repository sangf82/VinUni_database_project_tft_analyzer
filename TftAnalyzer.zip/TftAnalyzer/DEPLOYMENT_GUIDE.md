# TFT Analyzer - Deployment Guide

## Quick Start Instructions

### Option 1: Run on Replit (Recommended - Easiest)

1. **Fork this Replit project** or upload all files to a new Replit
2. **Click the "Run" button** - that's it! The app will automatically:
   - Install all dependencies
   - Set up the PostgreSQL database
   - Create sample data with 30 VN players
   - Start the web server

3. **Access your app** at the provided Replit URL
4. **Login with sample accounts**:
   - Username: `tln_yby1` Password: `password123`
   - Username: `saigon_buffalo_shenlong` Password: `password123`
   - Or any of the 30 pre-created accounts (all use `password123`)

### Option 2: Run Locally

#### Prerequisites
- Python 3.8+
- PostgreSQL database

#### Steps
1. **Download all project files** to your computer
2. **Install Python dependencies**:
   ```bash
   pip install flask flask-sqlalchemy gunicorn psycopg2-binary werkzeug email-validator
   ```
3. **Set up PostgreSQL database**:
   ```bash
   # Create database
   createdb tft_analyzer
   
   # Set environment variable
   export DATABASE_URL="postgresql://your_username:your_password@localhost:5432/tft_analyzer"
   export SESSION_SECRET="your_secret_key_here"
   ```
4. **Run the application**:
   ```bash
   python main.py
   ```
5. **Open browser** to `http://localhost:5000`

## What You Get

### 30 Pre-loaded Players
The app comes with realistic sample data for top VN TFT players including:
- TLN YBY1 (Challenger 1,952 LP)
- Saigon Buffalo Shenlong (Grandmaster 1,831 LP)
- Team Flash NoWay (Master 1,703 LP)
- And 27 more players with complete match histories

### Features Ready to Use
- ✅ **Player Dashboard** with comprehensive statistics
- ✅ **MetaTFT-style Recent Games** with expandable team compositions
- ✅ **Interactive Charts** for LP progression and placement distribution
- ✅ **Leaderboard** with real-time rankings
- ✅ **Champion Data** with authentic League of Legends images
- ✅ **Responsive Design** works on all devices
- ✅ **Dark Theme** matching TFT aesthetics

### Login Credentials
All 30 sample users use the same password: `password123`

Sample usernames:
- tln_yby1
- saigon_buffalo_shenlong
- team_flash_noway
- gam_esports_zeros
- cerberus_esports_rip
- (and 25 more)

## File Structure
```
tft-analyzer/
├── main.py              # Start the app
├── app.py               # Flask configuration
├── models.py            # Database models
├── routes.py            # Web routes
├── data_manager.py      # Data utilities
├── sample_data.py       # Sample data creation
├── utils.py             # Helper functions
├── static/              # CSS, JS, images
├── templates/           # HTML templates
└── pyproject.toml       # Dependencies
```

## Troubleshooting

### App Won't Start
- Check Python version (3.8+ required)
- Ensure all dependencies are installed
- Verify database connection

### Database Issues
- Make sure PostgreSQL is running
- Check DATABASE_URL environment variable
- Ensure database exists and is accessible

### Missing Images
- Champion images load from League of Legends CDN
- Check internet connection
- Fallback placeholders will show if images fail

## Customization Options

### Add Real Riot API Integration
To connect to live Riot Games data, you'll need:
1. Riot Developer API key
2. Update data fetching functions
3. Implement real-time data sync

### Modify Sample Data
Edit `sample_data.py` to:
- Add more players
- Change match histories
- Update statistics

### Styling Changes
Modify files in `static/css/` to customize:
- Color schemes
- Layout adjustments
- Component styling

## Support

If you encounter any issues:
1. Check this guide first
2. Ensure all prerequisites are met
3. Verify environment variables are set
4. Check browser console for JavaScript errors

---

**Ready to explore TFT analytics like never before!** 🎮