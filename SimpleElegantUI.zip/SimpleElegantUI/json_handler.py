import json
import os
import logging
from datetime import datetime

class JSONHandler:
    """Handle saving and loading player data from JSON files"""
    
    def __init__(self):
        self.data_folder = "player_data"
        self.sample_file = "attached_assets/stat.json"
        self.ensure_data_folder()
    
    def ensure_data_folder(self):
        """Create data folder if it doesn't exist"""
        if not os.path.exists(self.data_folder):
            os.makedirs(self.data_folder)
    
    def get_player_filename(self, riot_name, riot_tag):
        """Get filename for player data"""
        safe_name = f"{riot_name}_{riot_tag}".replace("#", "_").replace(" ", "_")
        return os.path.join(self.data_folder, f"{safe_name}.json")
    
    def save_player_data(self, riot_name, riot_tag, data):
        """Save player data to JSON file"""
        try:
            filename = self.get_player_filename(riot_name, riot_tag)
            
            # Add timestamp to data
            data['last_saved'] = datetime.utcnow().isoformat()
            
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)
            
            logging.info(f"Saved player data for {riot_name}#{riot_tag} to {filename}")
            return True
            
        except Exception as e:
            logging.error(f"Error saving player data: {e}")
            return False
    
    def load_player_data(self, riot_name, riot_tag):
        """Load player data from JSON file"""
        try:
            filename = self.get_player_filename(riot_name, riot_tag)
            
            if os.path.exists(filename):
                with open(filename, 'r') as f:
                    data = json.load(f)
                logging.info(f"Loaded player data for {riot_name}#{riot_tag} from {filename}")
                return data
            else:
                logging.info(f"No saved data found for {riot_name}#{riot_tag}")
                return None
                
        except Exception as e:
            logging.error(f"Error loading player data: {e}")
            return None
    
    def load_sample_data(self):
        """Load sample data from stat.json"""
        try:
            if os.path.exists(self.sample_file):
                with open(self.sample_file, 'r') as f:
                    data = json.load(f)
                logging.info("Loaded sample data from stat.json")
                return data
            else:
                logging.warning("Sample data file not found")
                return None
                
        except Exception as e:
            logging.error(f"Error loading sample data: {e}")
            return None
    
    def is_data_empty(self, data):
        """Check if player data is empty or invalid"""
        if not data:
            return True
        
        # Check if essential data exists
        if 'ranked' not in data:
            return True
        
        ranked_data = data['ranked']
        if not ranked_data or ranked_data.get('num_games', 0) == 0:
            return True
        
        return False
    
    def get_best_available_data(self, riot_name, riot_tag):
        """Get the best available data - saved, API, or sample"""
        # Try to load saved data first
        saved_data = self.load_player_data(riot_name, riot_tag)
        
        if saved_data and not self.is_data_empty(saved_data):
            return saved_data, "saved"
        
        # If no saved data or empty, return sample data
        sample_data = self.load_sample_data()
        if sample_data and not self.is_data_empty(sample_data):
            return sample_data, "sample"
        
        return None, "none"