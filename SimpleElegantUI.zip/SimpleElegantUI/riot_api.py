import os
import requests
import logging
from datetime import datetime, timedelta
from models import PlayerStats, MatchHistory, Champion, ChampionPick, LPHistory
from app import db
import random
import urllib.parse
from json_handler import JSONHandler

class RiotAPI:
    """MetaTFT API integration for real TFT data"""
    
    def __init__(self):
        self.metatft_base_url = 'https://api.metatft.com/public'
        self.tft_set = 'TFTSet14'  # Current TFT set
        self.json_handler = JSONHandler()
        
        # Rank data
        self.tiers = ['IRON', 'BRONZE', 'SILVER', 'GOLD', 'PLATINUM', 'DIAMOND', 'MASTER', 'GRANDMASTER', 'CHALLENGER']
        self.ranks = ['IV', 'III', 'II', 'I']
    
    def _initialize_champions(self):
        """Initialize TFT champions in the database"""
        try:
            if Champion.query.count() == 0:
                champions_data = [
                    {'name': 'Aatrox', 'cost': 1, 'health': 650, 'attack_damage': 55, 'armor': 35, 'magic_resist': 35},
                    {'name': 'Ahri', 'cost': 2, 'health': 500, 'attack_damage': 40, 'armor': 20, 'magic_resist': 20},
                    {'name': 'Akali', 'cost': 3, 'health': 650, 'attack_damage': 65, 'armor': 35, 'magic_resist': 35},
                    {'name': 'Azir', 'cost': 4, 'health': 700, 'attack_damage': 45, 'armor': 25, 'magic_resist': 25},
                    {'name': 'Bard', 'cost': 5, 'health': 800, 'attack_damage': 50, 'armor': 35, 'magic_resist': 35},
                    {'name': 'Braum', 'cost': 2, 'health': 750, 'attack_damage': 50, 'armor': 50, 'magic_resist': 50},
                    {'name': 'Cassiopeia', 'cost': 3, 'health': 600, 'attack_damage': 50, 'armor': 25, 'magic_resist': 25},
                    {'name': 'Diana', 'cost': 1, 'health': 600, 'attack_damage': 50, 'armor': 35, 'magic_resist': 35},
                    {'name': 'Draven', 'cost': 4, 'health': 650, 'attack_damage': 75, 'armor': 30, 'magic_resist': 30},
                    {'name': 'Ezreal', 'cost': 1, 'health': 500, 'attack_damage': 50, 'armor': 20, 'magic_resist': 20},
                    {'name': 'Fiora', 'cost': 1, 'health': 550, 'attack_damage': 60, 'armor': 30, 'magic_resist': 30},
                    {'name': 'Garen', 'cost': 1, 'health': 700, 'attack_damage': 55, 'armor': 40, 'magic_resist': 40},
                    {'name': 'Heimerdinger', 'cost': 5, 'health': 650, 'attack_damage': 45, 'armor': 25, 'magic_resist': 25},
                    {'name': 'Jinx', 'cost': 3, 'health': 550, 'attack_damage': 70, 'armor': 25, 'magic_resist': 25},
                    {'name': 'Karma', 'cost': 2, 'health': 500, 'attack_damage': 45, 'armor': 25, 'magic_resist': 25},
                    {'name': 'Katarina', 'cost': 3, 'health': 550, 'attack_damage': 65, 'armor': 25, 'magic_resist': 25},
                    {'name': 'Kayn', 'cost': 4, 'health': 750, 'attack_damage': 70, 'armor': 40, 'magic_resist': 40},
                    {'name': 'Leona', 'cost': 1, 'health': 750, 'attack_damage': 50, 'armor': 50, 'magic_resist': 50},
                    {'name': 'Lux', 'cost': 3, 'health': 500, 'attack_damage': 50, 'armor': 20, 'magic_resist': 20},
                    {'name': 'Morgana', 'cost': 4, 'health': 650, 'attack_damage': 50, 'armor': 30, 'magic_resist': 30},
                ]
                
                for champ_data in champions_data:
                    champion = Champion(**champ_data)
                    db.session.add(champion)
                
                try:
                    db.session.commit()
                    logging.info("Initialized TFT champions in database")
                except Exception as e:
                    db.session.rollback()
                    logging.error(f"Error initializing champions: {e}")
        except Exception as e:
            logging.warning(f"Could not initialize champions - database may not be ready: {e}")
    
    def get_player_data_from_metatft(self, riot_name, riot_tag, region='TR1'):
        """Fetch player data from API or JSON files"""
        try:
            # First try to get data from best available source
            data, source = self.json_handler.get_best_available_data(riot_name, riot_tag)
            
            if data and source == "saved":
                logging.info(f"Using saved data for {riot_name}#{riot_tag}")
                return data
            
            # If no saved data, try API
            # URL encode each part separately to handle spaces and special characters
            encoded_name = urllib.parse.quote(riot_name, safe='')
            encoded_tag = urllib.parse.quote(riot_tag, safe='')
            encoded_riot_id = f"{encoded_name}/{encoded_tag}"
            
            # Build the API URL
            url = f"{self.metatft_base_url}/profile/lookup_by_riotid/{region}/{encoded_riot_id}?source=full_profile&tft_set={self.tft_set}&include_revival_matches=true"
            
            logging.info(f"Fetching data from MetaTFT API: {url}")
            
            # Make the API request
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                api_data = response.json()
                # Save successful API response
                self.json_handler.save_player_data(riot_name, riot_tag, api_data)
                logging.info(f"Successfully fetched and saved data for {riot_name}#{riot_tag}")
                return api_data
            else:
                # API failed, use sample data if available
                if data and source == "sample":
                    logging.info(f"API failed, using sample data for {riot_name}#{riot_tag}")
                    return data
                
                error_message = self._get_api_error_message(response.status_code, riot_name, riot_tag)
                logging.error(f"MetaTFT API returned status {response.status_code} for {riot_name}#{riot_tag}: {error_message}")
                return {'error': error_message, 'status_code': response.status_code}
                
        except requests.exceptions.RequestException as e:
            # Connection error, try sample data
            data, source = self.json_handler.get_best_available_data(riot_name, riot_tag)
            if data:
                logging.info(f"Connection error, using {source} data for {riot_name}#{riot_tag}")
                return data
            
            logging.error(f"Error fetching data from MetaTFT API: {e}")
            return {'error': f"Connection error: {str(e)}", 'status_code': 'connection_error'}
        except Exception as e:
            logging.error(f"Unexpected error fetching MetaTFT data: {e}")
            return {'error': f"Connection error: {str(e)}", 'status_code': 'connection_error'}
    
    def _get_api_error_message(self, status_code, riot_name, riot_tag):
        """Get user-friendly error message based on API status code"""
        error_messages = {
            404: f"Player '{riot_name}#{riot_tag}' not found. Please check:\n• Riot ID spelling is correct\n• Player has played TFT ranked games\n• Player profile is not private",
            403: "Access denied to player data. The profile might be private or restricted.",
            429: "Too many requests to the API. Please try again in a few minutes.",
            500: "MetaTFT API is currently unavailable. Please try again later.",
            503: "MetaTFT service is temporarily unavailable for maintenance."
        }
        
        return error_messages.get(status_code, f"API error (Status {status_code}). Please try again later.")
    
    def validate_data_received(self, metatft_data, riot_name, riot_tag):
        """Validate if we received proper data and return user-friendly message"""
        if not metatft_data:
            return False, "No data received from MetaTFT API. Please try again."
        
        if 'error' in metatft_data:
            return False, metatft_data['error']
        
        # Check if essential data is present
        if 'summoner' not in metatft_data:
            return False, f"Invalid player data for {riot_name}#{riot_tag}. Player might not exist or have no TFT games."
        
        if 'ranked' not in metatft_data:
            return False, f"No ranked data found for {riot_name}#{riot_tag}. Player might not have played ranked TFT this season."
        
        # Check if player has any games
        ranked_data = metatft_data['ranked']
        num_games = ranked_data.get('num_games', 0)
        
        if num_games == 0:
            return False, f"{riot_name}#{riot_tag} has not played any ranked TFT games this season."
        
        return True, f"Successfully loaded data for {riot_name}#{riot_tag} ({num_games} games played)"
    
    def get_tft_league_data(self, summoner_id):
        """Mock function to get TFT league data"""
        # Generate mock ranked data
        tier_index = random.randint(0, len(self.tiers) - 1)
        tier = self.tiers[tier_index]
        
        if tier in ['MASTER', 'GRANDMASTER', 'CHALLENGER']:
            rank = None
            lp = random.randint(0, 2000)
        else:
            rank = random.choice(self.ranks)
            lp = random.randint(0, 100)
        
        wins = random.randint(50, 200)
        losses = random.randint(30, 150)
        
        return {
            'tier': tier,
            'rank': rank,
            'leaguePoints': lp,
            'wins': wins,
            'losses': losses,
            'veteran': False,
            'inactive': False,
            'freshBlood': False,
            'hotStreak': random.choice([True, False])
        }
    
    def get_match_history(self, puuid, count=20):
        """Mock function to get match history"""
        matches = []
        base_date = datetime.now()
        
        for i in range(count):
            match_date = base_date - timedelta(days=i, hours=random.randint(0, 23))
            placement = random.randint(1, 8)
            
            # Calculate LP change based on placement
            if placement <= 4:
                lp_change = random.randint(10, 40)
            else:
                lp_change = random.randint(-50, -10)
            
            matches.append({
                'match_id': f"NA1_{int(match_date.timestamp())}_{i}",
                'placement': placement,
                'lp_change': lp_change,
                'game_length': random.randint(1200, 2400),  # 20-40 minutes
                'played_at': match_date,
                'game_version': '13.24'
            })
        
        return matches
    
    def get_match_details(self, match_id):
        """Mock function to get detailed match information"""
        champions = Champion.query.all()
        if not champions:
            return []
        
        # Generate 3-6 champion picks for the match
        num_picks = random.randint(3, 6)
        selected_champions = random.sample(champions, min(num_picks, len(champions)))
        
        picks = []
        for champion in selected_champions:
            picks.append({
                'champion_id': champion.id,
                'star_level': random.randint(1, 3),
                'items': []  # Could add item data here
            })
        
        return picks
    
    def update_player_data(self, user):
        """Update player data from MetaTFT API"""
        try:
            # Get real data from MetaTFT API
            metatft_data = self.get_player_data_from_metatft(user.riot_name, user.riot_tag)
            
            # Validate the data received
            is_valid, message = self.validate_data_received(metatft_data, user.riot_name, user.riot_tag)
            
            if not is_valid:
                logging.warning(f"Data validation failed for {user.riot_name}#{user.riot_tag}: {message}")
                # Store the error message for the user interface
                user.last_api_error = message
                return {'success': False, 'message': message}
            
            # Update player stats
            stats = PlayerStats.query.filter_by(user_id=user.id).first()
            if not stats:
                stats = PlayerStats(user_id=user.id)
                db.session.add(stats)
            
            # Store previous LP for history tracking
            previous_lp = stats.league_points
            
            # Extract data from MetaTFT response
            if 'ranked' in metatft_data:
                ranked_data = metatft_data['ranked']
                
                # Parse rating text (e.g., "CHALLENGER I 2186 LP")
                rating_text = ranked_data.get('rating_text', 'UNRANKED')
                
                # Extract tier, rank, and LP from rating text
                if 'LP' in rating_text:
                    parts = rating_text.split()
                    if len(parts) >= 3:
                        stats.tier = parts[0].upper()  # CHALLENGER
                        stats.rank = parts[1] if parts[1] in ['I', 'II', 'III', 'IV'] else 'I'  # I
                        # Extract LP number
                        lp_part = parts[-2]  # The number before "LP"
                        try:
                            stats.league_points = int(lp_part)
                        except ValueError:
                            stats.league_points = 0
                    else:
                        stats.tier = 'UNRANKED'
                        stats.rank = 'IV'
                        stats.league_points = 0
                else:
                    stats.tier = 'UNRANKED'
                    stats.rank = 'IV'
                    stats.league_points = 0
                
                # Get number of games
                stats.games_played = ranked_data.get('num_games', 0)
                
                # For wins/losses, we'll estimate based on average performance
                # This is approximate since MetaTFT doesn't provide exact W/L
                estimated_win_rate = 0.6  # Assume decent win rate for ranked players
                stats.wins = int(stats.games_played * estimated_win_rate)
                stats.losses = stats.games_played - stats.wins
            
            # Update average placement from matches if available
            if 'matches' in metatft_data and metatft_data['matches']:
                total_placement = sum(match.get('placement', 4) for match in metatft_data['matches'])
                stats.average_placement = total_placement / len(metatft_data['matches'])
            
            stats.last_updated = datetime.utcnow()
            
            # Add LP history entry if LP changed significantly
            if abs(stats.league_points - previous_lp) >= 10:
                lp_entry = LPHistory(
                    user_id=user.id,
                    lp_value=stats.league_points,
                    tier=stats.tier,
                    rank=stats.rank
                )
                db.session.add(lp_entry)
            
            # Generate some LP history if user has none
            existing_history = LPHistory.query.filter_by(user_id=user.id).count()
            if existing_history == 0:
                self._generate_lp_history_from_metatft(user.id, metatft_data)
            
            # Update match history from MetaTFT data
            if 'matches' in metatft_data:
                self._update_match_history_from_metatft(user, metatft_data['matches'])
            
            logging.info(f"Updated player data for {user.username} from MetaTFT API")
            
        except Exception as e:
            logging.error(f"Error updating player data for {user.username}: {e}")
            raise
    
    def _generate_lp_history_from_metatft(self, user_id, metatft_data):
        """Generate LP history from MetaTFT rating changes"""
        try:
            if 'ranked_rating_changes' not in metatft_data:
                return
                
            rating_changes = metatft_data['ranked_rating_changes']
            
            # Process the rating changes (they come in reverse chronological order)
            for change in rating_changes[-20:]:  # Take last 20 entries for history
                rating_text = change.get('rating_text', 'UNRANKED')
                created_timestamp = change.get('created_timestamp', '')
                
                # Parse rating text to extract LP
                lp_value = 0
                tier = 'UNRANKED'
                rank = 'IV'
                
                if 'LP' in rating_text:
                    parts = rating_text.split()
                    if len(parts) >= 3:
                        tier = parts[0].upper()
                        rank = parts[1] if parts[1] in ['I', 'II', 'III', 'IV'] else 'I'
                        try:
                            lp_value = int(parts[-2])  # Number before "LP"
                        except ValueError:
                            lp_value = 0
                
                # Parse timestamp
                try:
                    if created_timestamp:
                        # Remove milliseconds if present and parse
                        timestamp_clean = created_timestamp.split('.')[0]
                        recorded_at = datetime.fromisoformat(timestamp_clean.replace('Z', ''))
                    else:
                        recorded_at = datetime.utcnow()
                except:
                    recorded_at = datetime.utcnow()
                
                lp_entry = LPHistory(
                    user_id=user_id,
                    lp_value=lp_value,
                    tier=tier,
                    rank=rank,
                    recorded_at=recorded_at
                )
                db.session.add(lp_entry)
                
        except Exception as e:
            logging.error(f"Error generating LP history from MetaTFT data: {e}")
    
    def _update_match_history_from_metatft(self, user, matches_data):
        """Update match history from MetaTFT data"""
        try:
            for match_data in matches_data[:10]:  # Limit to recent 10 matches
                match_id = match_data.get('match_id', f"meta_{random.randint(1000, 9999)}")
                
                # Check if match already exists
                existing = MatchHistory.query.filter_by(
                    user_id=user.id,
                    match_id=match_id
                ).first()
                
                if not existing:
                    placement = match_data.get('placement', 4)
                    
                    # Calculate LP change based on placement
                    if placement <= 4:
                        lp_change = random.randint(10, 40)
                    else:
                        lp_change = random.randint(-50, -10)
                    
                    match = MatchHistory(
                        user_id=user.id,
                        match_id=match_id,
                        placement=placement,
                        lp_change=lp_change,
                        lp_after=match_data.get('lp_after', 1200),
                        game_length=match_data.get('game_length', 1800),
                        game_version=self.tft_set,
                        played_at=datetime.fromtimestamp(match_data.get('game_datetime', datetime.now().timestamp()))
                    )
                    db.session.add(match)
                    
        except Exception as e:
            logging.error(f"Error updating match history from MetaTFT: {e}")
    
    def _generate_lp_history(self, user_id, current_lp, current_tier, current_rank):
        """Generate mock LP history for visualization"""
        history_points = []
        base_date = datetime.utcnow() - timedelta(days=30)
        
        # Start from a lower LP and work up to current
        start_lp = max(0, current_lp - random.randint(200, 500))
        
        for i in range(30):
            date = base_date + timedelta(days=i)
            
            # Gradually increase LP with some variance
            progress = i / 30
            lp = int(start_lp + (current_lp - start_lp) * progress + random.randint(-50, 50))
            lp = max(0, lp)
            
            history_points.append({
                'date': date,
                'lp': lp,
                'tier': current_tier,
                'rank': current_rank
            })
        
        # Add to database
        for point in history_points:
            lp_entry = LPHistory(
                user_id=user_id,
                lp_value=point['lp'],
                tier=point['tier'],
                rank=point['rank'],
                recorded_at=point['date']
            )
            db.session.add(lp_entry)
    
    def _update_match_history(self, user, puuid):
        """Update match history for user"""
        try:
            # Get recent matches
            matches_data = self.get_match_history(puuid, 10)
            
            for match_data in matches_data:
                # Check if match already exists
                existing = MatchHistory.query.filter_by(
                    user_id=user.id,
                    match_id=match_data['match_id']
                ).first()
                
                if not existing:
                    # Create new match record
                    match = MatchHistory(
                        user_id=user.id,
                        match_id=match_data['match_id'],
                        placement=match_data['placement'],
                        lp_change=match_data['lp_change'],
                        lp_after=match_data.get('lp_after', 0),
                        game_length=match_data['game_length'],
                        game_version=match_data['game_version'],
                        played_at=match_data['played_at']
                    )
                    db.session.add(match)
                    db.session.flush()  # Get the ID
                    
                    # Add champion picks for this match
                    champion_picks = self.get_match_details(match_data['match_id'])
                    for pick_data in champion_picks:
                        pick = ChampionPick(
                            match_id=match.id,
                            champion_id=pick_data['champion_id'],
                            star_level=pick_data['star_level'],
                            items=str(pick_data['items'])
                        )
                        db.session.add(pick)
        
        except Exception as e:
            logging.error(f"Error updating match history: {e}")
    
    def get_top_champions(self, user_id, limit=3):
        """Get user's most played champions"""
        try:
            # Query to get champion usage from matches
            from sqlalchemy import func
            
            query = db.session.query(
                Champion.name,
                Champion.cost,
                Champion.image_url,
                func.count(ChampionPick.id).label('pick_count')
            ).join(
                ChampionPick, Champion.id == ChampionPick.champion_id
            ).join(
                MatchHistory, ChampionPick.match_id == MatchHistory.id
            ).filter(
                MatchHistory.user_id == user_id
            ).group_by(
                Champion.id, Champion.name, Champion.cost, Champion.image_url
            ).order_by(
                func.count(ChampionPick.id).desc()
            ).limit(limit)
            
            results = query.all()
            
            top_champions = []
            for result in results:
                top_champions.append({
                    'name': result.name,
                    'cost': result.cost,
                    'pick_count': result.pick_count,
                    'image_url': result.image_url or f"https://ddragon.leagueoflegends.com/cdn/13.24.1/img/champion/{result.name}.png"
                })
            
            # If no data, return some default champions
            if not top_champions:
                default_champions = Champion.query.limit(3).all()
                for champ in default_champions:
                    top_champions.append({
                        'name': champ.name,
                        'cost': champ.cost,
                        'pick_count': random.randint(1, 5),
                        'image_url': champ.image_url or f"https://ddragon.leagueoflegends.com/cdn/13.24.1/img/champion/{champ.name}.png"
                    })
            
            return top_champions
            
        except Exception as e:
            logging.error(f"Error getting top champions: {e}")
            return []
