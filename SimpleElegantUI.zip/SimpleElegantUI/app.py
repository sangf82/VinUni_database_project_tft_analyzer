import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Set up logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///tft_analyzer.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)

with app.app_context():
    # Import models and routes
    import models
    import routes
    
    # Create all tables
    db.create_all()
    
    # Handle database schema updates
    try:
        # Check if last_api_error column exists, if not add it
        from sqlalchemy import text
        result = db.session.execute(text("PRAGMA table_info(user)")).fetchall()
        columns = [row[1] for row in result]
        
        if 'last_api_error' not in columns:
            db.session.execute(text("ALTER TABLE user ADD COLUMN last_api_error TEXT"))
            db.session.commit()
            logging.info("Added last_api_error column to user table")
    except Exception as e:
        logging.debug(f"Schema update note: {e}")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
