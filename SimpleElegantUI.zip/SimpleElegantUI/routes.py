from flask import render_template, request, redirect, url_for, flash, session, jsonify
from app import app, db
from models import User, PlayerStats, MatchHistory, Champion, ChampionPick, LPHistory
from utils import login_required
from datetime import datetime, timedelta
import logging

# Global riot API instance
_riot_api = None

def get_riot_api():
    """Get RiotAPI instance, initializing it after database is ready"""
    global _riot_api
    if _riot_api is None:
        from riot_api import RiotAPI
        _riot_api = RiotAPI()
        _riot_api._initialize_champions()
    return _riot_api

@app.route('/')
def index():
    """Landing page"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        riot_id = request.form.get('riot_id', '').strip()
        
        # Validation
        if not username or not password or not riot_id:
            flash('All fields are required.', 'error')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return render_template('register.html')
        
        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'error')
            return render_template('register.html')
        
        if not User.validate_riot_id(riot_id):
            flash('Invalid Riot ID format. Use format: username#tag (e.g., Player#1234)', 'error')
            return render_template('register.html')
        
        # Check if username already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists. Please choose a different one.', 'error')
            return render_template('register.html')
        
        # Parse Riot ID
        riot_name, riot_tag = riot_id.split('#')
        
        # Check if Riot ID already exists
        existing_riot = User.query.filter_by(riot_name=riot_name, riot_tag=riot_tag).first()
        if existing_riot:
            flash('This Riot ID is already registered.', 'error')
            return render_template('register.html')
        
        try:
            # Create new user
            user = User(
                username=username,
                riot_name=riot_name,
                riot_tag=riot_tag
            )
            user.set_password(password)
            
            db.session.add(user)
            db.session.commit()
            
            # Create initial player stats
            stats = PlayerStats(user_id=user.id)
            db.session.add(stats)
            db.session.commit()
            
            # Try to fetch initial data from Riot API
            try:
                riot_api = get_riot_api()
                riot_api.update_player_data(user)
            except Exception as e:
                logging.warning(f"Could not fetch initial Riot data for {riot_id}: {e}")
            
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
            
        except Exception as e:
            db.session.rollback()
            logging.error(f"Registration error: {e}")
            flash('An error occurred during registration. Please try again.', 'error')
            
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        if not username or not password:
            flash('Username and password are required.', 'error')
            return render_template('login.html')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username
            flash(f'Welcome back, {user.username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password.', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """User logout"""
    username = session.get('username', 'User')
    session.clear()
    flash(f'Goodbye, {username}!', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard"""
    user_id = session['user_id']
    user = User.query.get(user_id)
    
    if not user:
        flash('User not found. Please log in again.', 'error')
        return redirect(url_for('login'))
    
    # Get or create player stats
    stats = PlayerStats.query.filter_by(user_id=user_id).first()
    if not stats:
        stats = PlayerStats(user_id=user_id)
        db.session.add(stats)
        db.session.commit()
    
    # Update data from Riot API and track data source
    data_source = "MetaTFT API"
    try:
        if not stats.last_updated or (datetime.utcnow() - stats.last_updated) > timedelta(minutes=5):
            riot_api = get_riot_api()
            result = riot_api.update_player_data(user)
            if result and not result.get('success', True):
                data_source = "Sample Data (stat.json)"
            db.session.commit()
    except Exception as e:
        logging.error(f"Error updating Riot data: {e}")
        data_source = "Sample Data (stat.json)"
        flash('Using sample data for demonstration. Refresh to try API again.', 'info')
    
    # Get recent match history
    recent_matches = MatchHistory.query.filter_by(user_id=user_id).order_by(MatchHistory.played_at.desc()).limit(10).all()
    
    # Get LP history for chart
    lp_history = LPHistory.query.filter_by(user_id=user_id).order_by(LPHistory.recorded_at.asc()).limit(30).all()
    
    # Get top 3 champions
    riot_api = get_riot_api()
    top_champions = riot_api.get_top_champions(user_id)
    
    return render_template('dashboard.html', 
                         user=user, 
                         stats=stats, 
                         recent_matches=recent_matches,
                         lp_history=lp_history,
                         top_champions=top_champions,
                         data_source=data_source)

@app.route('/api/lp-history/<int:user_id>')
@login_required
def api_lp_history(user_id):
    """API endpoint for LP history data"""
    if session['user_id'] != user_id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    lp_history = LPHistory.query.filter_by(user_id=user_id).order_by(LPHistory.recorded_at.asc()).all()
    
    data = []
    for record in lp_history:
        data.append({
            'date': record.recorded_at.strftime('%Y-%m-%d %H:%M'),
            'lp': record.lp_value,
            'tier': record.tier,
            'rank': record.rank
        })
    
    return jsonify(data)

@app.route('/refresh-data')
@login_required
def refresh_data():
    """Manually refresh player data from Riot API"""
    user_id = session['user_id']
    user = User.query.get(user_id)
    
    if not user:
        flash('User not found.', 'error')
        return redirect(url_for('dashboard'))
    
    try:
        riot_api.update_player_data(user)
        db.session.commit()
        flash('Data refreshed successfully!', 'success')
    except Exception as e:
        logging.error(f"Error refreshing data: {e}")
        flash('Could not refresh data from Riot Games. Please try again later.', 'error')
    
    return redirect(url_for('dashboard'))

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500
