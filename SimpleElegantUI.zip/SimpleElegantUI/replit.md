# TFT Analyzer

## Overview

TFT Analyzer is a Flask-based web application designed to track and analyze Teamfight Tactics (TFT) player performance. The application allows users to register with their Riot ID, automatically fetches their match data and statistics through the Riot Games API, and provides comprehensive dashboards with match history, LP tracking, champion analytics, and rank progression visualizations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a traditional Flask MVC architecture with the following key components:

### Backend Architecture
- **Flask Framework**: Core web framework handling routing, request processing, and response generation
- **SQLAlchemy ORM**: Database abstraction layer for model definitions and query operations
- **Gunicorn WSGI Server**: Production-ready web server for deployment
- **Session-based Authentication**: Uses Flask sessions for user authentication and state management

### Frontend Architecture
- **Server-side Rendering**: HTML templates rendered using Jinja2 templating engine
- **Bootstrap 5**: Responsive CSS framework with dark theme for gaming aesthetic
- **Chart.js**: Client-side charting library for data visualizations
- **Font Awesome**: Icon library for enhanced UI elements
- **Custom CSS/JS**: Application-specific styling and interactivity

### Database Architecture
- **SQLAlchemy Models**: Object-relational mapping for database entities
- **Flexible Database Support**: Configured to support both SQLite (development) and PostgreSQL (production)
- **Relationship Management**: Proper foreign key relationships with cascade delete operations

## Key Components

### User Management System
- **User Registration**: Validates Riot ID format and creates user accounts with hashed passwords
- **Authentication**: Session-based login system with password verification using Werkzeug
- **User Profile**: Links users to their Riot Games accounts for data fetching

### Riot API Integration
- **Mock API Implementation**: Currently uses mock data for demonstration purposes
- **Rate Limiting Ready**: Structured to handle Riot API rate limits when implemented
- **Data Caching**: Designed to cache API responses for performance optimization
- **Champion Database**: Maintains TFT champion data including stats and costs

### Data Models
- **User Model**: Stores authentication credentials and Riot ID information
- **PlayerStats**: Current rank information (tier, rank, LP)
- **MatchHistory**: Individual match records with placement and performance data
- **Champion/ChampionPick**: TFT champion data and player usage statistics
- **LPHistory**: League Points progression tracking over time

### Dashboard System
- **Performance Metrics**: Average placement, win rate, and rank progression
- **Match History**: Detailed view of recent games with placement and LP changes
- **Champion Analytics**: Most played champions and success rates
- **LP Progression**: Visual charts showing rank climb over time

## Data Flow

1. **User Registration**: User provides username, password, and Riot ID → Validation → Database storage with hashed credentials
2. **Authentication**: Login credentials verified → Session established → User redirected to dashboard
3. **Data Fetching**: Riot ID used to query mock API → Player stats and match history retrieved → Database updated
4. **Dashboard Rendering**: User data aggregated → Statistics calculated → HTML templates rendered with visualizations
5. **Data Refresh**: Manual refresh triggers new API calls → Updated data stored → Dashboard refreshed with latest information

## External Dependencies

### Core Framework Dependencies
- **Flask**: Web framework (v3.1.1)
- **Flask-SQLAlchemy**: Database ORM (v3.1.1)
- **Flask-Login**: User session management (v0.6.3)
- **Flask-WTF**: Form handling and CSRF protection (v1.2.2)
- **Werkzeug**: WSGI utilities and password hashing (v3.1.3)

### Database and API Dependencies
- **SQLAlchemy**: Database toolkit (v2.0.41)
- **psycopg2-binary**: PostgreSQL adapter (v2.9.10)
- **Requests**: HTTP library for API calls (v2.32.3)

### Production Dependencies
- **Gunicorn**: WSGI HTTP server (v23.0.0)
- **Email-validator**: Email validation utilities (v2.2.0)

### Frontend Dependencies (CDN)
- **Bootstrap 5.3.0**: CSS framework
- **Chart.js**: Data visualization library
- **Font Awesome 6.4.0**: Icon library

## Deployment Strategy

### Development Environment
- **Local SQLite**: File-based database for development (`tft_analyzer.db`)
- **Flask Development Server**: Built-in server with debug mode enabled
- **Environment Variables**: Configuration through environment variables with sensible defaults

### Production Environment
- **Gunicorn WSGI Server**: Multi-worker production server configuration
- **PostgreSQL Database**: Production-grade database with connection pooling
- **Autoscale Deployment**: Configured for automatic scaling based on traffic
- **Environment Configuration**: Production settings override development defaults

### Security Considerations
- **Password Hashing**: Werkzeug's secure password hashing implementation
- **Session Security**: Configurable session secret with strong default
- **CSRF Protection**: Built-in protection through Flask-WTF
- **Proxy Support**: ProxyFix middleware for proper header handling behind reverse proxies

### Database Configuration
- **Connection Pooling**: SQLAlchemy engine options for connection management
- **Health Checks**: Pre-ping enabled for connection validation
- **Migration Ready**: Structure supports future database migrations
- **Environment-based URLs**: Flexible database URL configuration for different environments